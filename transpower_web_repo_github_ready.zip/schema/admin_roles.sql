
create table if not exists admin_roles (
  user_id uuid primary key references users(id),
  role text default 'admin'
);

insert into admin_roles (user_id, role)
values ('00000000-0000-0000-0000-000000000001', 'admin')
on conflict (user_id) do update set role = excluded.role;
