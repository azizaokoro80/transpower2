
create table if not exists users (
  id uuid primary key references auth.users(id),
  full_name text,
  pronouns text,
  avatar_url text,
  created_at timestamp default now()
);
