
insert into users (id, full_name, pronouns, avatar_url, created_at)
values (
  '00000000-0000-0000-0000-000000000001',
  'Aziza Okoro',
  'she/they',
  'https://example.com/avatar.png',
  now()
)
on conflict (id) do update set
  full_name = excluded.full_name,
  pronouns = excluded.pronouns,
  avatar_url = excluded.avatar_url;
