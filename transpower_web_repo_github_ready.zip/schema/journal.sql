
create table if not exists journal (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id),
  entry text,
  mood text,
  created_at timestamp default now()
);
