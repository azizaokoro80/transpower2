
create table if not exists kits (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id),
  title text,
  description text,
  category text,
  created_at timestamp default now()
);
