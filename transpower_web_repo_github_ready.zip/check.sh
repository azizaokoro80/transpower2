#!/bin/bash
echo "🔍 Running TypeScript syntax check..."
npx tsc --noEmit

echo "📦 Installing dependencies..."
npm install

echo "🧪 Building project for production..."
npm run build

echo "🚀 Starting local server..."
npm run start

echo "✅ Done! Visit http://localhost:3000 to test your app."
