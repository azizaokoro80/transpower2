
import { useState } from 'react';
import Fuse from 'fuse.js';

type SearchItem = {
  name: string;
  category: string;
  link: string;
};

const sampleData: SearchItem[] = [
  { name: 'Gender-Affirming Surgeons', category: 'Health', link: '/directory/surgeons' },
  { name: 'NA Meeting Finder', category: 'Support', link: '/support/na' },
  { name: 'LGBTQ Youth Center', category: 'Community', link: '/youth' },
  { name: 'Resume Builder', category: 'Training', link: '/tools/resume' },
  { name: 'Peer Training Videos', category: 'Education', link: '/training/videos' }
];

const fuse = new Fuse(sampleData, {
  keys: ['name', 'category'],
  includeScore: true,
  threshold: 0.3
});

export default function FuzzySearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchItem[]>([]);

  const handleSearch = (input: string) => {
    setQuery(input);
    const searchResults = fuse.search(input);
    setResults(searchResults.map(result => result.item));
  };

  return (
    <div className="p-4 bg-gray-900 rounded-xl text-white">
      <input
        type="text"
        className="w-full p-2 rounded bg-gray-800 text-white"
        placeholder="Search for anything in Baltimore…"
        value={query}
        onChange={e => handleSearch(e.target.value)}
      />
      <ul className="mt-4 space-y-2">
        {results.map((item, index) => (
          <li key={index} className="p-3 bg-gray-800 rounded hover:bg-purple-800 transition">
            <a href={item.link} className="block">
              <strong>{item.name}</strong> <span className="text-sm text-purple-300">({item.category})</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
