
import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { supabase } from '@/lib/supabase';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
});

export default function MapView() {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    supabase.from('resources').select('*').then(({ data }) => {
      if (data) setLocations(data);
    });
  }, []);

  return (
    <div className="h-[80vh] w-full">
      <MapContainer center={[39.2904, -76.6122]} zoom={13} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {locations.map((loc: any) => (
          <Marker key={loc.id} position={[loc.lat, loc.lng]}>
            <Popup>
              <strong>{loc.name}</strong><br />
              {loc.category}<br />
              <a href={loc.website || '#'} target="_blank" className="text-blue-600">More Info</a>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
