
# TransPower Baltimore 🌆🏳️‍⚧️

A fully affirming, real-time, NeoAfroGoth themed empowerment app for the trans and LGBTQ+ community of Baltimore.

## 🌍 Features
- Fuzzy global search for services
- Supabase-powered database + auth
- NeoAfroGoth theming + custom mode switcher
- Leaflet-based geo search & “Near Me” filters
- Calendar, mood tracker, journal, affirmations
- Push alerts, offline fallback, and mobile-ready

## 🔧 Run Locally
```bash
npm install
npm run dev
```

## 🚀 Deploy to Vercel
1. Push this folder to GitHub
2. Visit https://vercel.com/import
3. Select your repo and deploy

## 👤 Admin Quote
“Reintegration is revolution. Healing is power. Welcome home.” — Aziza Okoro
