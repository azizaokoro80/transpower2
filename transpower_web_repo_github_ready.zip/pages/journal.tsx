
import { useEffect, useState } from 'react';
import { supabase, getUser } from '@/lib/supabase';

export default function JournalPage() {
  const [entry, setEntry] = useState('');
  const [mood, setMood] = useState('');
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    getUser().then(user => {
      if (user) {
        supabase.from('journal').select('*').eq('user_id', user.id).then(({ data }) => setEntries(data || []));
      }
    });
  }, []);

  const handleSubmit = async () => {
    const user = await getUser();
    const { data } = await supabase.from('journal').insert({ user_id: user.id, entry, mood });
    if (data) setEntries(prev => [...prev, ...data]);
    setEntry('');
    setMood('');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📓 Journal</h1>
      <textarea value={entry} onChange={(e) => setEntry(e.target.value)} placeholder="Write your thoughts..." className="mb-2 p-2 border w-full" />
      <input value={mood} onChange={(e) => setMood(e.target.value)} placeholder="Mood" className="mb-2 p-2 border w-full" />
      <button onClick={handleSubmit} className="bg-green-600 text-white px-4 py-2 rounded">Save Entry</button>
      <ul className="mt-4 space-y-2">
        {entries.map((j: any) => (
          <li key={j.id} className="border p-3 rounded bg-white shadow"><strong>{j.mood}:</strong> {j.entry}</li>
        ))}
      </ul>
    </div>
  );
}
