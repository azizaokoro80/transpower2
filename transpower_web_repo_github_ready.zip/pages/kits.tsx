
import { useEffect, useState } from 'react';
import { supabase, getUser } from '@/lib/supabase';

export default function KitsPage() {
  const [kits, setKits] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    getUser().then(user => {
      if (user) {
        supabase.from('kits').select('*').eq('user_id', user.id).then(({ data }) => setKits(data || []));
      }
    });
  }, []);

  const handleAddKit = async () => {
    const user = await getUser();
    const { data } = await supabase.from('kits').insert({ user_id: user.id, title, description });
    if (data) setKits(prev => [...prev, ...data]);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧰 My Resource Kits</h1>
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="mb-2 p-2 border w-full" />
      <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="mb-2 p-2 border w-full" />
      <button onClick={handleAddKit} className="bg-blue-600 text-white px-4 py-2 rounded">Add Kit</button>
      <ul className="mt-4 space-y-2">
        {kits.map((kit: any) => (
          <li key={kit.id} className="border p-3 rounded bg-white shadow">{kit.title}: {kit.description}</li>
        ))}
      </ul>
    </div>
  );
}
