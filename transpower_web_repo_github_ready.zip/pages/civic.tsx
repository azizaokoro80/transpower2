
export default function CivicCenter() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🏛️ Civic Action Center</h1>
      <p>Find your trans-affirming reps, vote, and get your rights known.</p>
      <ul className="mt-4 list-disc pl-6">
        <li><a className="text-blue-600 underline" href="https://www.vote.org" target="_blank">Register to vote</a></li>
        <li>Contact Baltimore City LGBTQ Affairs: (link)</li>
        <li>Know Your Rights guides (employment, housing, healthcare)</li>
      </ul>
    </div>
  );
}
