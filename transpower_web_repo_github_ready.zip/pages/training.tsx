
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function TrainingHub() {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    supabase.from('training_videos').select('*').then(({ data }) => {
      if (data) setVideos(data);
    });
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🎥 Training & Empowerment Videos</h1>
      <p className="mb-4">Learn at your own pace. These videos are downloadable and accessible anytime.</p>
      <ul className="space-y-4">
        {videos.map((video: any) => (
          <li key={video.id} className="border rounded p-4 shadow bg-white">
            <h2 className="text-xl font-semibold">{video.title}</h2>
            <p className="mb-2">{video.description}</p>
            <div className="aspect-video">
              <iframe
                className="w-full h-60"
                src={video.link}
                title={video.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
            {video.download_url && (
              <a
                href={video.download_url}
                target="_blank"
                className="inline-block mt-3 text-blue-600 underline"
              >
                ⬇️ Download Video
              </a>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
