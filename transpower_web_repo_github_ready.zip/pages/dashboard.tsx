
export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">🧭 Your Dashboard</h1>
      <p>Welcome back. What do you need today?</p>
      <ul className="list-disc pl-6 mt-4 space-y-2">
        <li><a href="/kits">View Your Kits</a></li>
        <li><a href="/journal">Write in Journal</a></li>
        <li><a href="/resources">Search Resources</a></li>
        <li><a href="/training">Training Videos</a></li>
        <li><a href="/id-toolkit">Name & ID Toolkit</a></li>
        <li><a href="/zine">Creative Story Wall</a></li>
        <li><a href="/civic">Civic Action Hub</a></li>
      </ul>
    </div>
  );
}
