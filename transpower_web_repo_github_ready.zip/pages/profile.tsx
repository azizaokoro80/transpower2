
import { useEffect, useState } from 'react';
import { supabase, getUser } from '@/lib/supabase';

export default function ProfilePage() {
  const [userData, setUserData] = useState({ full_name: '', pronouns: '', avatar_url: '' });

  useEffect(() => {
    getUser().then(user => {
      if (user) {
        supabase.from('users').select('*').eq('id', user.id).single().then(({ data }) => {
          if (data) setUserData(data);
        });
      }
    });
  }, []);

  const handleUpdate = async () => {
    const user = await getUser();
    await supabase.from('users').upsert({ id: user.id, ...userData });
    alert('Profile updated!');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">👤 Profile</h1>
      <input value={userData.full_name} onChange={(e) => setUserData({ ...userData, full_name: e.target.value })} placeholder="Full name" className="mb-2 p-2 border w-full" />
      <input value={userData.pronouns} onChange={(e) => setUserData({ ...userData, pronouns: e.target.value })} placeholder="Pronouns" className="mb-2 p-2 border w-full" />
      <input value={userData.avatar_url} onChange={(e) => setUserData({ ...userData, avatar_url: e.target.value })} placeholder="Avatar URL" className="mb-2 p-2 border w-full" />
      <button onClick={handleUpdate} className="bg-purple-600 text-white px-4 py-2 rounded">Save</button>
    </div>
  );
}
