
export default function OfflineFallback() {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-black text-white text-center p-6">
      <h1 className="text-3xl font-bold text-purple-400 mb-4">You're Offline</h1>
      <p className="max-w-xl text-lg italic">
        It looks like you’re offline. But don’t worry — power lives in you even without a signal.
      </p>
      <p className="mt-4 text-sm text-gray-400">Reconnect when you can. We’ll still be here.</p>
    </div>
  );
}
