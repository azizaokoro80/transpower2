
export default function ZinePage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🖼️ Digital Zine / Story Wall</h1>
      <p>Submit your art, poems, and stories to share with the community.</p>
      <div className="mt-4">[Upload component placeholder]</div>
    </div>
  );
}
