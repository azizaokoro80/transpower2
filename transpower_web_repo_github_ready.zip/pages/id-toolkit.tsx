
export default function IDToolkit() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🪪 Name & ID Transition Toolkit</h1>
      <p>Steps to legally update your name and gender marker in Maryland:</p>
      <ol className="list-decimal pl-6 space-y-2 mt-4">
        <li>Download and complete the name change petition form.</li>
        <li>File with your local circuit court (Baltimore City Court link).</li>
        <li>Obtain certified copies to update your SSA and MVA records.</li>
        <li>Use your updated documents to change medical and job info.</li>
      </ol>
      <a href="https://mdcourts.gov" target="_blank" className="text-blue-600 underline mt-4 block">More info & forms</a>
    </div>
  );
}
